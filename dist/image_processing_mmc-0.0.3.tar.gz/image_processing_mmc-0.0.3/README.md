# image_processing_dio

Description. 
The package image_processing_dio is used to: 
	Processing:
		- Histogram matching
		- Structural similarity
		- Resized image
    Utils:
       - Read image
       - Save image
       - Plot image
       - Plot result
       - Plot histogram

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install image_processing_dio

```bash
pip install image_processing_dio
```

## Author

monicacaetano

## License

[MIT](https://choosealicense.com/licenses/mit/)